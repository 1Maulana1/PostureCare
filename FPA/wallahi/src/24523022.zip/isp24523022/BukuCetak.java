package isp24523022;
public class BukuCetak extends Buku {

    public BukuCetak(String judul, String penulis, int tahun) {
        super(judul, penulis, tahun);
    }

    @Override
    public void tampilkanInfo() {
        System.out.println("Buku Cetak:");
        System.out.println("Judul: " + judul);
        System.out.println("Penulis: " + penulis);
        System.out.println("Tahun: " + tahun);
    }
}
