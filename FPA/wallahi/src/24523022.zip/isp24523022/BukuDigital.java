package isp24523022;
public class BukuDigital extends Buku implements Digital {

    public BukuDigital(String judul, String penulis, int tahun) {
        super(judul, penulis, tahun);
    }

    @Override
    public void tampilkanInfo() {
        System.out.println("Buku Digital:");
        System.out.println("Judul: " + judul);
        System.out.println("Penulis: " + penulis);
        System.out.println("Tahun: " + tahun);
    }

    @Override
    public void download() {
        System.out.println("Mengunduh buku digital: " + judul);
    }
}