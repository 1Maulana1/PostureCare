package isp24523022;
public abstract class Buku {
    protected String judul;
    protected String penulis;
    protected int tahun;

    public Buku(String judul, String penulis, int tahun) {
        this.judul = judul;
        this.penulis = penulis;
        this.tahun = tahun;
    }

    public abstract void tampilkanInfo();

    // Getter
    public String getJudul() { return judul; }
    public String getPenulis() { return penulis; }
    public int getTahun() { return tahun; }
}