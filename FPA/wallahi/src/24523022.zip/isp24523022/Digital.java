package isp24523022;
public interface Digital {
    void download();
}