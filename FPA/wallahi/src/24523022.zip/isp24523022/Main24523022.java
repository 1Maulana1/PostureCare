package isp24523022;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;

public class Main24523022 {
    public static void main(String[] args) {
        ArrayList<BukuCetak> daftarBukuCetak = new ArrayList<>();
        ArrayList<BukuDigital> daftarBukuDigital = new ArrayList<>();

        // Tambahkan 3 buku cetak
        daftarBukuCetak.add(new BukuCetak("Pemrograman Java", "Marcel", 2020));
        daftarBukuCetak.add(new BukuCetak("Algoritma Lanjut", "Dio", 2019));
        daftarBukuCetak.add(new BukuCetak("Struktur Algoritma", "Agus", 2021));

        // Tambahkan 3 buku digital
        daftarBukuDigital.add(new BukuDigital("Machine Learning", "Mala", 2022));
        daftarBukuDigital.add(new BukuDigital("Cloud Computing", "Eko", 2023));
        daftarBukuDigital.add(new BukuDigital("Big Data", "Bela", 2021));

        Scanner scanner = new Scanner(System.in);
        System.out.println("1. Simpan Daftar Buku Cetak");
        System.out.println("2. Simpan Daftar Buku Digital");
        System.out.print("Pilih menu: ");
        int pilihan = scanner.nextInt();

        if (pilihan == 1) {
            simpanBukuCetakXML(daftarBukuCetak);
            System.out.println("Daftar Buku Cetak berhasil disimpan ke Bukucetak.xml");
        } else if (pilihan == 2) {
            simpanBukuDigitalXML(daftarBukuDigital);
            System.out.println("Daftar Buku Digital berhasil disimpan ke Bukudigital.xml");
        } else {
            System.out.println("Pilihan tidak valid.");
        }
        scanner.close();
    }

    private static void simpanBukuCetakXML(ArrayList<BukuCetak> daftar) {
        try (FileWriter writer = new FileWriter("bukucetak.xml")) {
            writer.write("<bukucetak>\n");
            for (BukuCetak buku : daftar) {
                writer.write("  <buku>\n");
                writer.write("    <judul>" + buku.getJudul() + "</judul>\n");
                writer.write("    <penulis>" + buku.getPenulis() + "</penulis>\n");
                writer.write("    <tahun>" + buku.getTahun() + "</tahun>\n");
                writer.write("  </buku>\n");
            }
            writer.write("</bukucetak>");
        } catch (IOException e) {
            System.out.println("Gagal menyimpan file XML: " + e.getMessage());
        }
    }

    private static void simpanBukuDigitalXML(ArrayList<BukuDigital> daftar) {
        try (FileWriter writer = new FileWriter("bukudigital.xml")) {
            writer.write("<bukudigital>\n");
            for (BukuDigital buku : daftar) {
                writer.write("  <buku>\n");
                writer.write("    <judul>" + buku.getJudul() + "</judul>\n");
                writer.write("    <penulis>" + buku.getPenulis() + "</penulis>\n");
                writer.write("    <tahun>" + buku.getTahun() + "</tahun>\n");
                writer.write("  </buku>\n");
            }
            writer.write("</bukudigital>");
        } catch (IOException e) {
            System.out.println("Gagal menyimpan file XML: " + e.getMessage());
        }
    }
}